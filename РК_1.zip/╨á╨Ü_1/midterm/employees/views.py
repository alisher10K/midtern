from django.shortcuts import render
from rest_framework import viewsets
from .models import Employee
from .serializers import EmployeeSerializer
from rest_framework import permissions

# Create your views here.
class EmployeeViewSet(viewsets.ModelViewSet):
    permission_classes = [permissions.AllowAny]
    serializer_class = EmployeeSerializer
    queryset = Employee.objects.all()
    
